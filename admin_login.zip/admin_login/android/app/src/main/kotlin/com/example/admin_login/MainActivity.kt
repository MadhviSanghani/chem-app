package com.example.admin_login

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
